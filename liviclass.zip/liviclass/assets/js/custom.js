jQuery(document).ready(function () {
    var $owl = jQuery(".owl-carousel");

    $owl.on("initialized.owl.carousel resized.owl.carousel", function (e) {
      jQuery(e.target).toggleClass("hide-nav", e.item.count <= e.page.size);
    });

    $owl.owlCarousel({
      nav: true,
      margin: 20,
      stagePadding: 5,
      navText: [
        '<i class="fa fa-angle-left" aria-hidden="true"></i>',
        '<i class="fa fa-angle-right" aria-hidden="true"></i>',
      ],
      loop: false,
      navRewind: false,
      responsiveClass: true,
      responsive: {
        0: {
          items: 1,
          nav: false,
        },
        576: {
          items: 2,
          nav: false,
        },
        992: {
          items: 3,
          nav: true
        },
      },
    });

    // Add minus icon for collapse element which is open by default
    jQuery(".collapse.show").each(function () {
      jQuery(this)
        .prev(".card-header")
        .find(".fa")
        .addClass("fa-minus")
        .removeClass("fa-plus");
    });

    // Toggle plus minus icon on show hide of collapse element
    jQuery(".collapse")
      .on("show.bs.collapse", function () {
        jQuery(this)
          .prev(".card-header")
          .find(".fa")
          .removeClass("fa-plus")
          .addClass("fa-minus");
      })
      .on("hide.bs.collapse", function () {
        jQuery(this)
          .prev(".card-header")
          .find(".fa")
          .removeClass("fa-minus")
          .addClass("fa-plus");
      });
  });