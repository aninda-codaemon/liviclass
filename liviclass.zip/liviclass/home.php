<?php
/*
	Template Name: Home
*/
get_header(); ?>
<section class="banner">
	<div class="container">
	<div class="row">
		<div class="col-md-8 col-lg-6">
		<h1>Get started today with our virtual classes</h1>
		<h3>We have many different classes, start today</h3>
		<div class="search-area">
			<form class="search-with-btn">
			<input
				type="text"
				name="search"
				id="search"
				placeholder="What do you want to learn?"
				value=""
			/>
			<button type="submit">
				Search<i
				class="fa fa-long-arrow-right"
				aria-hidden="true"
				></i>
			</button>
			</form>
			<div class="hint d-flex">
			<h6>Try:</h6>
			<ul>
				<li class="active">Health &amp; Fitness</li>
				<li>Cooking</li>
				<li>Social</li>
			</ul>
			</div>
		</div>
		</div>
	</div>
	</div>
</section>
<section class="explore-new-classes pad-80">
	<div class="container">
	<div class="row align-items-center">
		<div class="col-md-5 col-lg-4">
		<h2>Explore Our New Classes of All Categories</h2>
		</div>
		<div class="col-md-7 col-lg-8">
		<div class="owl-carousel">
			<div class="classes-thumb">
			<figure>
				<img src="<?php bloginfo('template_url'); ?>/assets/images/class1.png" alt="class" />
			</figure>
			<div class="content">
				<h4>Yoga class for complete beginners</h4>
				<h6>by <strong>Anna White</strong></h6>
				<img src="<?php bloginfo('template_url'); ?>/assets/images/rating.jpg" class="rating" alt="rating" />
				<div class="row align-items-center">
				<div class="col-md-6 duration">1h 15min</div>
				<div class="col-md-6 price text-md-right">$11.56</div>
				</div>
			</div>
			</div>
			<div class="classes-thumb">
			<figure>
				<img src="<?php bloginfo('template_url'); ?>/assets/images/class2.png" alt="class" />
			</figure>
			<div class="content">
				<h4>Fitness class for complete beginners</h4>
				<h6>by <strong>Anna White</strong></h6>
				<img src="<?php bloginfo('template_url'); ?>/assets/images/rating.jpg" class="rating" alt="rating" />
				<div class="row align-items-center">
				<div class="col-md-6 duration">1h 15min</div>
				<div class="col-md-6 price text-md-right">$11.56</div>
				</div>
			</div>
			</div>
			<div class="classes-thumb">
			<figure>
				<img src="<?php bloginfo('template_url'); ?>/assets/images/class3.png" alt="class" />
			</figure>
			<div class="content">
				<h4>Cooking class for complete beginners</h4>
				<h6>by <strong>Anna White</strong></h6>
				<img src="<?php bloginfo('template_url'); ?>/assets/images/rating.jpg" class="rating" alt="rating" />
				<div class="row align-items-center">
				<div class="col-md-6 duration">1h 15min</div>
				<div class="col-md-6 price text-md-right">$11.56</div>
				</div>
			</div>
			</div>
			<div class="classes-thumb">
			<figure>
				<img src="<?php bloginfo('template_url'); ?>/assets/images/class1.png" alt="class" />
			</figure>
			<div class="content">
				<h4>Yoga class for complete beginners</h4>
				<h6>by <strong>Anna White</strong></h6>
				<img src="<?php bloginfo('template_url'); ?>/assets/images/rating.jpg" class="rating" alt="rating" />
				<div class="row align-items-center">
				<div class="col-md-6 duration">1h 15min</div>
				<div class="col-md-6 price text-md-right">$11.56</div>
				</div>
			</div>
			</div>
		</div>
		<a href="#" class="custom-cta ml-10"
			>Browse All Classes
			<i class="fa fa-long-arrow-right" aria-hidden="true"></i
		></a>
		</div>
	</div>
	</div>
</section>
<section class="about-us pad-80">
	<div class="container">
	<div class="row align-items-center">
		<article class="col-md-6">
		<h2 class="mb-30">About us</h2>
		<p class="para mb-50">
			Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet sunt
			totam cum velit quod ut nostrum ullam. Odio, repellendus ipsum.
			Et, sit perspiciatis rerum quas quae voluptas expedita ipsum
			nulla. Lorem ipsum dolor sit amet consectetur adipisicing elit.
			Repellat vero veniam explicabo tenetur neque at voluptatibus fuga
			quo eum cupiditate iure minus culpa natus maiores officia ex
			possimus, dicta fugiat.
		</p>
		<a href="<?php echo site_url(); ?>/about-us/" class="custom-cta light"
			>Learn More
			<i class="fa fa-long-arrow-right" aria-hidden="true"></i
		></a>
		</article>
		<div class="col-md-6">
		<div class="row mb-30">
			<figure class="col-md-6">
			<img src="<?php echo get_template_directory_uri(); ?>/assets/images/about1.jpg" alt="about" />
			</figure>
			<figure class="col-md-6">
			<video controls poster="<?php bloginfo('template_url'); ?>/assets/images/about2.jpg">
				<source src="<?php bloginfo('template_url'); ?>/assets/video/mov_bbb.mp4" type="video/mp4" />
				Your browser does not support HTML video.
			</video>
			</figure>
		</div>
		<div class="row">
			<figure class="col-md-6">
			<img src="<?php bloginfo('template_url'); ?>/assets/images/about3.jpg" alt="e-larning" />
			</figure>
			<figure class="col-md-6">
			<img src="<?php bloginfo('template_url'); ?>/assets/images/about4.jpg" alt="online education" />
			</figure>
		</div>
		</div>
	</div>
	</div>
</section>
<section class="faq-area pad-80">
	<div class="container">
	<h2 class="mb-30">Common Questions</h2>
	<div class="accordion" id="accordionExample">
		<div class="card">
		<div class="card-header" id="heading1">
			<h2 class="mb-0">
			<button
				class="btn btn-link btn-block text-left"
				type="button"
				data-toggle="collapse"
				data-target="#collapse1"
				aria-expanded="true"
				aria-controls="collapse1"
			>
				<i class="fa fa-plus" aria-hidden="true"></i>How can I help
				support my favorite studios during COVID-19?
			</button>
			</h2>
		</div>

		<div
			id="collapse1"
			class="collapse show"
			aria-labelledby="heading1"
			data-parent="#accordionExample"
		>
			<div class="card-body">
			Anim pariatur cliche reprehenderit, enim eiusmod high life
			accusamus terry richardson ad squid. 3 wolf moon officia aute,
			non cupidatat skateboard dolor brunch. Food truck quinoa
			nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua
			put a bird on it squid single-origin coffee nulla assumenda
			shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore
			wes anderson cred nesciunt sapiente ea proident. Ad vegan
			excepteur butcher vice lomo. Leggings occaecat craft beer
			farm-to-table, raw denim aesthetic synth nesciunt you probably
			haven't heard of them accusamus labore sustainable VHS.
			</div>
		</div>
		</div>
		<div class="card">
		<div class="card-header" id="heading2">
			<h2 class="mb-0">
			<button
				class="btn btn-link btn-block text-left collapsed"
				type="button"
				data-toggle="collapse"
				data-target="#collapse2"
				aria-expanded="false"
				aria-controls="collapse2"
			>
				<i class="fa fa-plus" aria-hidden="true"></i>How do I reserve
				a digital?
			</button>
			</h2>
		</div>
		<div
			id="collapse2"
			class="collapse"
			aria-labelledby="heading2"
			data-parent="#accordionExample"
		>
			<div class="card-body">
			Anim pariatur cliche reprehenderit, enim eiusmod high life
			accusamus terry richardson ad squid. 3 wolf moon officia aute,
			non cupidatat skateboard dolor brunch. Food truck quinoa
			nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua
			put a bird on it squid single-origin coffee nulla assumenda
			shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore
			wes anderson cred nesciunt sapiente ea proident. Ad vegan
			excepteur butcher vice lomo. Leggings occaecat craft beer
			farm-to-table, raw denim aesthetic synth nesciunt you probably
			haven't heard of them accusamus labore sustainable VHS.
			</div>
		</div>
		</div>
		<div class="card">
		<div class="card-header" id="heading3">
			<h2 class="mb-0">
			<button
				class="btn btn-link btn-block text-left collapsed"
				type="button"
				data-toggle="collapse"
				data-target="#collapse3"
				aria-expanded="false"
				aria-controls="collapse3"
			>
				<i class="fa fa-plus" aria-hidden="true"></i>What if I need to
				cancel my digital?
			</button>
			</h2>
		</div>
		<div
			id="collapse3"
			class="collapse"
			aria-labelledby="heading3"
			data-parent="#accordionExample"
		>
			<div class="card-body">
			Anim pariatur cliche reprehenderit, enim eiusmod high life
			accusamus terry richardson ad squid. 3 wolf moon officia aute,
			non cupidatat skateboard dolor brunch. Food truck quinoa
			nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua
			put a bird on it squid single-origin coffee nulla assumenda
			shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore
			wes anderson cred nesciunt sapiente ea proident. Ad vegan
			excepteur butcher vice lomo. Leggings occaecat craft beer
			farm-to-table, raw denim aesthetic synth nesciunt you probably
			haven't heard of them accusamus labore sustainable VHS.
			</div>
		</div>
		</div>
		<div class="card">
		<div class="card-header" id="heading4">
			<h2 class="mb-0">
			<button
				class="btn btn-link btn-block text-left collapsed"
				type="button"
				data-toggle="collapse"
				data-target="#collapse4"
				aria-expanded="false"
				aria-controls="collapse4"
			>
				<i class="fa fa-plus" aria-hidden="true"></i>How do I join a
				livestreaming class?
			</button>
			</h2>
		</div>
		<div
			id="collapse4"
			class="collapse"
			aria-labelledby="heading4"
			data-parent="#accordionExample"
		>
			<div class="card-body">
			Anim pariatur cliche reprehenderit, enim eiusmod high life
			accusamus terry richardson ad squid. 3 wolf moon officia aute,
			non cupidatat skateboard dolor brunch. Food truck quinoa
			nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua
			put a bird on it squid single-origin coffee nulla assumenda
			shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore
			wes anderson cred nesciunt sapiente ea proident. Ad vegan
			excepteur butcher vice lomo. Leggings occaecat craft beer
			farm-to-table, raw denim aesthetic synth nesciunt you probably
			haven't heard of them accusamus labore sustainable VHS.
			</div>
		</div>
		</div>
	</div>
	</div>
</section>
<section class="newsletter-area">
	<div class="container text-center">
	<div class="row justify-content-md-center">
		<div class="col-md-8">
		<h2>
			FutureLearn’s purpose is to transform access to education.<br />
			<strong>Ready to start today?</strong>
		</h2>
		<h4>
			Be the first to hear about our latest courses by signing up to our
			mailing list.
		</h4>

		<form class="search-with-btn mt-40">
			<input
			type="text"
			name="search"
			id="search"
			placeholder="Sign up for newsletter"
			value=""
			/>
			<button type="submit">
			Sign Up
			</button>
		</form>
		</div>
	</div>
	</div>
</section>

<?php
get_footer();
?>