<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since Twenty Seventeen 1.0
 * @version 1.2
 */

?>
<footer class="main">
	<div class="top-part">
	<div class="container">
		<div class="row">
		<div class="col-md-4">
			<figure>
			<a href="<?php echo site_url(); ?>"
				><img src="<?php bloginfo('template_url'); ?>/assets/images/footer-logo.png" alt="footer-logo"
			/></a>
			<ul class="social-media">
				<li>You can find us</li>
				<li>
				<a href="#"
					><img src="<?php bloginfo('template_url'); ?>/assets/images/facebook.png" alt="facebook"
				/></a>
				</li>
				<li>
				<a href="#"><img src="<?php bloginfo('template_url'); ?>/assets/images/insta.png" alt="instagram" /></a>
				</li>
				<li>
				<a href="#"><img src="<?php bloginfo('template_url'); ?>/assets/images/twitter.png" alt="twitter" /></a>
				</li>
			</ul>
			</figure>
		</div>
		<div class="col-md-8 footer-menu">
			<div class="row">
			<div class="col-md-4">
				<h3>Company</h3>
				<ul>
				<li><a href="<?php echo site_url(); ?>/why-virtual-classes/">Why virtual classes?</a></li>
				<li><a href="<?php echo site_url(); ?>/how-it-works">How it works?</a></li>
				<li><a href="<?php echo site_url(); ?>/about-us/">About us</a></li>
				<li><a href="<?php echo site_url(); ?>/gifts/">Gifts</a></li>
				</ul>
			</div>
			<div class="col-md-4">
				<h3>Partners</h3>
				<ul>
				<li><a href="<?php echo site_url(); ?>/become-a-partner/">Become a partner</a></li>
				<li><a href="<?php echo site_url(); ?>/donate/">Donate</a></li>
				</ul>
			</div>
			<div class="col-md-4">
				<h3>Support</h3>
				<ul>
				<li><a href="<?php echo site_url(); ?>/contact-us/">Contact Us</a></li>
				<li><a href="<?php echo site_url(); ?>/faq/">FAQ</a></li>
				</ul>
			</div>
			</div>
		</div>
		</div>
	</div>
	</div>
	<div class="bottom-part">
	<div class="container text-center">
		<ul>
		<li>
			<a href="#">Terms of use <span>|</span></a>
		</li>
		<li>
			<a href="#">Policy Cookies &amp; Ads <span>|</span></a>
		</li>
		<li><a href="#"> Accessibility</a></li>
		</ul>
	</div>
	</div>
</footer>
<?php wp_footer(); ?>

</body>
</html>
