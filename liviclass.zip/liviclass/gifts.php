<?php
/*
	Template Name: Gifts
*/
get_header(); ?>
<section class="about-us pad-80">
	<div class="container">
	<div class="row align-items-center">
		<article class="col-md-6">
		<h2 class="mb-30">Gifts</h2>
		<p class="para mb-50">
			Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet sunt
			totam cum velit quod ut nostrum ullam. Odio, repellendus ipsum.
			Et, sit perspiciatis rerum quas quae voluptas expedita ipsum
			nulla. Lorem ipsum dolor sit amet consectetur adipisicing elit.
			Repellat vero veniam explicabo tenetur neque at voluptatibus fuga
			quo eum cupiditate iure minus culpa natus maiores officia ex
			possimus, dicta fugiat.
		</p>
		<a href="#" class="custom-cta light"
			>Learn More
			<i class="fa fa-long-arrow-right" aria-hidden="true"></i
		></a>
		</article>
		
	</div>
	</div>
</section>
<?php
get_footer();
?>