<?php
/*
	Template Name: Sign In
*/
get_header(); ?>
<section class="sign-in">
      <div class="left-part">
        <figure>
          <img src="<?php bloginfo('template_url'); ?>/assets/images/footer-logo.png" class="img-fluid" alt="sign-in-logo" />
          <figcaption>Your website tagline goes here</figcaption>
        </figure>
      </div>
      <div class="right-part">
        <h1>Sign In</h1>
        <p class="para">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit. Unde sit aut
          repellat reprehenderit! Porro debitis reiciendis quaerat assumenda in
          ea rerum, aut voluptate numquam delectus, eos quod illum ex commodi?
        </p>
        <form>
          <div class="input-group">
            <input type="text" id="email" name="email"/>
            <label for="email">Email</label>
          </div>
          <div class="input-group show-hide">
            <input type="password" id="password" name="password"/>
            <label for="password">Your Password</label>
            <button type="button"><img src="<?php bloginfo('template_url'); ?>/assets/images/password.png" alt="password"/> <span>show</span></button>
          </div>
          <div class="row forgot-password-area">
            <div class="col-md-6">
              <div class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" id="customControlAutosizing">
                <label class="custom-control-label" for="customControlAutosizing">Remember me</label>
              </div>
            </div>
            <div class="col-md-6 text-md-right">
              <a href="#">Forgot Password</a>
            </div>
          </div>
          <button type="submit" class="btn btn-success">Sign Up</button>
          <div class="row">
            <div class="col-lg-6">
              <a href="#" class="social-login facebook"><img src="<?php bloginfo('template_url'); ?>/assets/images/facebook-login.png" alt="facebook login"/> Continue with Facebook</a>
            </div>
            <div class="col-lg-6">
              <a href="#" class="social-login google"><img src="<?php bloginfo('template_url'); ?>/assets/images/google.png" alt="google login" /> Continue with Google</a>
            </div>
          </div>
        </form>
      </div>
    </section>
<?php
get_footer();
?>