<?php
/*
	Template Name: About Us
*/
get_header(); ?>
<section class="about-us pad-80">
	<div class="container">
	<div class="row align-items-center">
		<article class="col-md-6">
		<h2 class="mb-30"><?php the_field('title'); ?></h2>
		<p class="para mb-50">
			<?php the_field('description', false, false); ?>
		</p>
	
		</article>
		<div class="col-md-6">
		<div class="row mb-30">
			<figure class="col-md-6">
			<img src="<?php echo get_field('right_image1')['sizes']['medium']; ?>" alt="about" />
			</figure>
			<figure class="col-md-6">
			<video controls poster="<?php bloginfo('template_url'); ?>/assets/images/about2.jpg">
				<source src="<?php bloginfo('template_url'); ?>/assets/video/mov_bbb.mp4" type="video/mp4" />
				Your browser does not support HTML video.
			</video>
			</figure>
		</div>
		<div class="row">
			<figure class="col-md-6">
			<img src="<?php echo get_field('right_image2')['sizes']['medium']; ?>" alt="e-larning" />
			</figure>
			<figure class="col-md-6">
			<img src="<?php bloginfo('template_url'); ?>/assets/images/about4.jpg" alt="online education" />
			</figure>
		</div>
		</div>
	</div>
	</div>
</section>
<?php
get_footer();
?>