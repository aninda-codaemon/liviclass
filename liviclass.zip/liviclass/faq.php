<?php
/*
	Template Name: Faq
*/
get_header(); ?>
<section class="faq-area pad-80">
	<div class="container">
	<h2 class="mb-30">Common Questions</h2>
	<div class="accordion" id="accordionExample">
		<div class="card">
		<div class="card-header" id="heading1">
			<h2 class="mb-0">
			<button
				class="btn btn-link btn-block text-left"
				type="button"
				data-toggle="collapse"
				data-target="#collapse1"
				aria-expanded="true"
				aria-controls="collapse1"
			>
				<i class="fa fa-plus" aria-hidden="true"></i>How can I help
				support my favorite studios during COVID-19?
			</button>
			</h2>
		</div>

		<div
			id="collapse1"
			class="collapse show"
			aria-labelledby="heading1"
			data-parent="#accordionExample"
		>
			<div class="card-body">
			Anim pariatur cliche reprehenderit, enim eiusmod high life
			accusamus terry richardson ad squid. 3 wolf moon officia aute,
			non cupidatat skateboard dolor brunch. Food truck quinoa
			nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua
			put a bird on it squid single-origin coffee nulla assumenda
			shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore
			wes anderson cred nesciunt sapiente ea proident. Ad vegan
			excepteur butcher vice lomo. Leggings occaecat craft beer
			farm-to-table, raw denim aesthetic synth nesciunt you probably
			haven't heard of them accusamus labore sustainable VHS.
			</div>
		</div>
		</div>
		<div class="card">
		<div class="card-header" id="heading2">
			<h2 class="mb-0">
			<button
				class="btn btn-link btn-block text-left collapsed"
				type="button"
				data-toggle="collapse"
				data-target="#collapse2"
				aria-expanded="false"
				aria-controls="collapse2"
			>
				<i class="fa fa-plus" aria-hidden="true"></i>How do I reserve
				a digital?
			</button>
			</h2>
		</div>
		<div
			id="collapse2"
			class="collapse"
			aria-labelledby="heading2"
			data-parent="#accordionExample"
		>
			<div class="card-body">
			Anim pariatur cliche reprehenderit, enim eiusmod high life
			accusamus terry richardson ad squid. 3 wolf moon officia aute,
			non cupidatat skateboard dolor brunch. Food truck quinoa
			nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua
			put a bird on it squid single-origin coffee nulla assumenda
			shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore
			wes anderson cred nesciunt sapiente ea proident. Ad vegan
			excepteur butcher vice lomo. Leggings occaecat craft beer
			farm-to-table, raw denim aesthetic synth nesciunt you probably
			haven't heard of them accusamus labore sustainable VHS.
			</div>
		</div>
		</div>
		<div class="card">
		<div class="card-header" id="heading3">
			<h2 class="mb-0">
			<button
				class="btn btn-link btn-block text-left collapsed"
				type="button"
				data-toggle="collapse"
				data-target="#collapse3"
				aria-expanded="false"
				aria-controls="collapse3"
			>
				<i class="fa fa-plus" aria-hidden="true"></i>What if I need to
				cancel my digital?
			</button>
			</h2>
		</div>
		<div
			id="collapse3"
			class="collapse"
			aria-labelledby="heading3"
			data-parent="#accordionExample"
		>
			<div class="card-body">
			Anim pariatur cliche reprehenderit, enim eiusmod high life
			accusamus terry richardson ad squid. 3 wolf moon officia aute,
			non cupidatat skateboard dolor brunch. Food truck quinoa
			nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua
			put a bird on it squid single-origin coffee nulla assumenda
			shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore
			wes anderson cred nesciunt sapiente ea proident. Ad vegan
			excepteur butcher vice lomo. Leggings occaecat craft beer
			farm-to-table, raw denim aesthetic synth nesciunt you probably
			haven't heard of them accusamus labore sustainable VHS.
			</div>
		</div>
		</div>
		<div class="card">
		<div class="card-header" id="heading4">
			<h2 class="mb-0">
			<button
				class="btn btn-link btn-block text-left collapsed"
				type="button"
				data-toggle="collapse"
				data-target="#collapse4"
				aria-expanded="false"
				aria-controls="collapse4"
			>
				<i class="fa fa-plus" aria-hidden="true"></i>How do I join a
				livestreaming class?
			</button>
			</h2>
		</div>
		<div
			id="collapse4"
			class="collapse"
			aria-labelledby="heading4"
			data-parent="#accordionExample"
		>
			<div class="card-body">
			Anim pariatur cliche reprehenderit, enim eiusmod high life
			accusamus terry richardson ad squid. 3 wolf moon officia aute,
			non cupidatat skateboard dolor brunch. Food truck quinoa
			nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua
			put a bird on it squid single-origin coffee nulla assumenda
			shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore
			wes anderson cred nesciunt sapiente ea proident. Ad vegan
			excepteur butcher vice lomo. Leggings occaecat craft beer
			farm-to-table, raw denim aesthetic synth nesciunt you probably
			haven't heard of them accusamus labore sustainable VHS.
			</div>
		</div>
		</div>
	</div>
	</div>
</section>
<?php
get_footer();
?>